"""
Filename: interview.py
Author: <Laudat, Noah>
Created: <25/8/2026>
Instructor: Holtslander
"""
x=input("what did you do for a living before this?")
print(x)
x=input("whats your income?")
print(x)
x=input("how many years of schooling experience do you have, if any?")
print(x)
x=input("whats your opinion on kids?")
print(x)
x=input("how well do you work under pressure?")
print(x)

